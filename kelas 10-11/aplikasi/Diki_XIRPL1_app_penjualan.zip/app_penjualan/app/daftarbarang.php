<!DOCTYPE html>
<head>
<title>Daftar Barang</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
<?php
include "menubarang.html";
?>
<div class="w3-container">
<div class="container">
<table width="519" border="1" class="w3-table-all w3-card-4">
  <caption align="top">
   <center><h4> Daftar Barang </h4></center>
  </caption>
  <tr>
    <th width="25" scope="col">No</th>
    <th width="103" scope="col">Kode Barang </th>
    <th width="128" scope="col">Nama Barang </th>
    <th width="60" scope="col">Harga</th>
    <th width="81" scope="col">Persediaan</th>
    <th width="82" scope="col">Action Edit</th>
     <th width="82" scope="col">Action Delete</th>
  </tr>
  </div>
</div>
<?php
//siapkan query untuk mengmbil semua data barang yang ada
include "koneksi.php";
$sql = "SELECT * FROM barang";
$kueri = mysqli_query($koneksi, $sql);
//karena datanya lebih dari 1 record maka gunakan while
//semua data disimpan dalam array
//loopnr untuk menampilkan data barang
$no = 1;
while($data = mysqli_fetch_array($kueri)){
    ?>
    <tr>
        <td><?php echo $no?></td>
        <td><?php //tampilin data dari database
        //$data adalah nama array yg kita buat
        // kodebarang adalah nama field yang ada di tabel
        echo $data['kodebarang']?></td>
        <td><?php echo $data['namabarang']?></td>
        <td><?php echo $data['harga']?></td>
        <td><?php echo $data['persediaan']?></td>
        <td><!-- buat link untuk edit dan delete dan berikan parameter dgn nama "kode"-->
        <a href="editbarang.php?kode=<?php 
        echo $data['kodebarang']?>">
        <button type="button" class="btn btn-warning"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg> Edit</button></a> 
        </td><td><a href="delete.php?kode=<?php 
        echo $data['kodebarang']?>">
        <button type="button" class="btn btn-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
</svg> Hapus</button></a></td>
    </tr>
    <?php
$no++;}
?>
</table>
</body>
</html>